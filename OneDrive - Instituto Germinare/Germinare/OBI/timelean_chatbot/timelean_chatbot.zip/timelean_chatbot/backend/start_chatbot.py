import subprocess
import os

# Caminho absoluto do Python do .venv
python_venv = os.path.join(os.getcwd(), ".venv", "Scripts", "python.exe")

# Caminho do main.py
main_path = os.path.join(os.getcwd(), "backend", "main.py")

try:
    # Colocando aspas para caminhos com espaços
    cmd = f'"{python_venv}" "{main_path}"'
    print("Executando comando:", cmd)
    subprocess.run(cmd, shell=True, check=True)
except subprocess.CalledProcessError as e:
    print("Erro ao iniciar o chatbot:", e)
